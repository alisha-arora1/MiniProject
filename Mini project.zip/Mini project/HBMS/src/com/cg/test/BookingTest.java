package com.cg.test;

import java.time.LocalDate;

import junit.framework.Assert;

import org.junit.Test;

import com.cg.bean.BookingDetails;
import com.cg.bean.Users;
import com.cg.dao.BookingDAOImpl;

import com.cg.exception.BookingException;



public class BookingTest {

	
	// test for addUser and addBookingDetails
	@Test
	public void testaddUser(){
		Users u1 = new Users();
	
		u1.setUserName("Ashish");
		u1.setPassword("102");
		u1.setMobileNo("9882222462");
		u1.setPhone("220390");
		u1.setAddress("address");
		u1.setEmail("suryaveersen@gmail.com");
		u1.setRole("customer");
		
		
		BookingDAOImpl dao= new BookingDAOImpl();
		try {
			String s= dao.addUser(u1);
			Assert.assertNotSame(0,s);
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	@Test
	public void testaddBookingDetails() throws BookingException{
		BookingDetails bk=  new BookingDetails();
		bk.setRoomId("1");
		bk.setBookedFrom(LocalDate.now());
		bk.setBookedTo(LocalDate.now());
		bk.setNumberOfAdults(3);
		bk.setNumberOfChildren(3);
		BookingDAOImpl dao= new BookingDAOImpl();
		try{
		BookingDetails s= dao.addBookingDetails(bk);
		Assert.assertNotSame(0,s);
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	 
}
