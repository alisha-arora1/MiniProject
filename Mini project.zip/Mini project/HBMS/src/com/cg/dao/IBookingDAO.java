package com.cg.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotel;
import com.cg.bean.RoomDetails;
import com.cg.bean.Users;
import com.cg.exception.BookingException;

public interface IBookingDAO {

	public boolean validateDetails(Users user)throws BookingException;
	public String addUser(Users user)throws BookingException;
	public boolean validateUser(String mobileNo,String password)throws BookingException;
	public List<Hotel> viewAllHotels()throws BookingException;
	public List<RoomDetails> getAllRooms(String hotelId)throws BookingException;
	public BookingDetails addBookingDetails(BookingDetails bookingDetails)throws BookingException;
	public BookingDetails viewBookingDetails(String bookingId) throws BookingException;
//	public Hotel addHotel(Hotel hotel);
//	public int deleteHotel(String hotelId);
//	public Hotel updateHotel(Hotel hotel);
//	public RoomDetails addRoom(RoomDetails room);
//	public int deleteRoom(RoomDetails room);
//	public RoomDetails updateRoom(RoomDetails room);
//	public List<BookingDetails> viewBookingDetails(String hotelId);
//	public List<Users> getGuestList(String hotelId);
//	public List<BookingDetails> viewBookings(LocalDate date);

}
