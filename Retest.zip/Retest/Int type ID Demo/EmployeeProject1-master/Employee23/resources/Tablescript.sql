CREATE TABLE Employee(employee_id NUMBER PRIMARY KEY,employee_name VARCHAR2(20),phone VARCHAR2(10), age NUMBER,regDate DATE);
CREATE SEQUENCE employee_Id_sequence
START WITH 1000;